local ITEM = Clockwork.item:New("weapon_base");

ITEM.name = "AI AW50";
ITEM.cost = 0;
ITEM.model = "models/weapons/w_acc_int_aw50.mdl";
ITEM.weight = 15;
ITEM.uniqueID = "m9k_aw50";
ITEM.business = false;
ITEM.description = "A fairly large sniper rifle, looks great, chambers 12.7x9mm NATO.";
ITEM.isAttachment = true;
ITEM.hasFlashlight = true;


ITEM.loweredOrigin = Vector(3, 0, -4);
ITEM.loweredAngles = Angle(0, 45, 0);
ITEM.attachmentBone = "ValveBiped.Bip01_Spine";
ITEM.attachmentOffsetAngles = Angle(0, 0, 0);
ITEM.attachmentOffsetVector = Vector(-4, 4, 4);

ITEM:Register();
